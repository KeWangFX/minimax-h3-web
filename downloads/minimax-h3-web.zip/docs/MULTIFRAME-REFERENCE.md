# Active mode: MiniMax H3 multi-reference images

Updated 2026-11-21. This supersedes the earlier single-first-frame I2V UI plan. No real inference was performed during development.

## User-facing behavior

- Upload 1–9 character, location, prop or composition references.
- Their stable order maps to `<Picture 1>`, `<Picture 2>`, … in the prompt.
- **No reference is implicitly fixed to the first or last frame.**
- An optional integer `frameIndex` explicitly anchors that reference to an interior frame. The UI/backend reject zero, the last frame, negative indices and conflicting references on one frame.
- Each anchored image remains a semantic `<Picture N>` reference as well as being passed to a chained `MiniMaxH3AddGuide` block.
- With no explicit anchors, the graph is the reference-conditioning subset of the official multi-frame-reference family, not a claim that a time-anchored multi-shot edit has already been specified.
- This is a local ComfyUI bridge. It does not call paid MiniMax APIs or download weights.

## Official source distinction

The official multi-frame template combines **ReferenceToVideo plus AddGuide**. Its example fixes frames at specific times, including a first frame. A plain I2V first-frame node is not a substitute, and semantic references alone must not be advertised as time-locked keyframes.

Primary documentation: <https://docs.comfy.org/tutorials/video/minimax/minimax-h3-multiframe>.

Official template repository inspected at commit `f77d47c355f9a6a0bec0e129b78b194a92d8d65b`:

| Template | Bytes | Raw SHA256 |
| --- | ---: | --- |
| `templates/video_minimax_h3_multiframe_reference.json` | 76433 | `6a2d22bec7b76b835124327c28e382aaf572ee54591dc23f49cd84ffdbb85d5d` |
| `templates/video_minimax_h3_r2v.json` | 46473 | `a79f1a8ae7d250f9da8b0f4e636e202526c37457b808e74fdf25de7ceed96574` |

Source URLs:

- <https://github.com/Comfy-Org/workflow_templates/blob/f77d47c355f9a6a0bec0e129b78b194a92d8d65b/templates/video_minimax_h3_multiframe_reference.json>
- <https://github.com/Comfy-Org/workflow_templates/blob/f77d47c355f9a6a0bec0e129b78b194a92d8d65b/templates/video_minimax_h3_r2v.json>

Core node/API schema inspected at ComfyUI commit `0072b8680dd2db0b6d68c06f718fa33bd92a728c`:

- `comfy_extras/nodes_minimax_h3.py`: ReferenceToVideo and AddGuide inputs/outputs.
- `comfy_extras/nodes_video.py`: CreateVideo and SaveVideo encoding.
- `comfy_api/latest/_io.py`: DynamicCombo and Autogrow expansion from flat API keys.

Source links:

- <https://github.com/comfyanonymous/ComfyUI/blob/0072b8680dd2db0b6d68c06f718fa33bd92a728c/comfy_extras/nodes_minimax_h3.py>
- <https://github.com/comfyanonymous/ComfyUI/blob/0072b8680dd2db0b6d68c06f718fa33bd92a728c/comfy_api/latest/_io.py>

## Active API graph

`UNETLoader (Ref2VA)`, CLIPLoader type=minimax, video/audio VAELoader, and one LoadImage per reference feed `MiniMaxH3ReferenceToVideo`. Reference slots are flat API inputs `ref_images.ref_image_0` through `_8`, in Picture order. The ReferenceToVideo outputs are conditioning at slot0 and packed audio/video latent at slot1.

Each explicitly anchored reference adds `MiniMaxH3AddGuide` with `positive` chained from the previous guide, the original packed latent, `image`, video VAE and `frame_idx`. Without an anchor no Guide node is inserted. There is no first-frame or end-frame connection.

The conditioned output feeds `BasicGuider`. `RandomNoise`, `KSamplerSelect`, `BasicScheduler` and the reference latent feed `SamplerCustomAdvanced`. Its packed latent output0 is connected independently to `VAEDecode` and `VAEDecodeAudio`; `CreateVideo` muxes them; `SaveVideo` exports the video. No implicit LoRA, turbo, bridge, refinement, image recoloring, raster blending or external-cache input is used.

Output prefix is `video/H3_Web/<unique-job-key>/clip`. A completed history output is accepted only when its filename/subfolder match the SaveVideo node stored in that same prompt's history. An unrelated video directory is not accepted as success.

## Parameters and quality boundaries

Defaults are 1344×768, 24fps, 124 frames, 50 steps, CFG1, `res_multistep`, beta scheduler, reference-image-size max. Fifty steps is a user-selected quality-oriented starting setting, not a measured universal optimum. The official template's full/non-turbo example uses 20 steps; its note suggests beta/normal can outperform simple for reference-heavy prompts. Per-shot tests remain necessary.

The official route uses BasicGuider with CFG1 and H3's native 24fps audio/video clock. The app rejects changing only the muxing FPS while pretending that the model generated a different frame rate. Canvas dimensions retain the core node's 32-pixel multiples and maximum16384; length uses 17k+5 frames within the core schema's maximum3600. Oversized canvases and durations beyond the roughly 5–15s trained range are experimental, not guaranteed quality improvements.

Precision `auto` prefers installed BF16 Ref2VA/Qwen weights. If only the named compatible INT8/NVFP4 files are installed, it selects and **reports** those exact files in `status.models`; it does not call them BF16. Precision `bf16` explicitly requires non-quantized candidates and fails rather than downgrading. Precision `int8` chooses the explicit INT8/NVFP4 profile. Model variants are never automatically downloaded.

Reference size `max` retains up to the source pipeline's 2048px short edge (downscale only), increasing identity-reference fidelity capacity and inference cost. It does not upscale a small source into real detail or guarantee perfect identity.

Encoding follows the live schema: current nested DynamicCombo, intermediate root DynamicCombo and old simple format/codec combos are distinguished. CRF16 is retained only where the chosen branch exposes it. Legacy default H.264 quality is explicitly labeled as such. A node's newly required unmapped field fails readiness instead of being guessed.

## Integration contract

Module: `lib/multiframe-adapter.mjs`.

`submitMultiReference({baseUrl, uploads:[{path,mime,name?,frameIndex?}], prompt, params, fetchImpl?})` returns `{promptId,seed,outputNodeId:'9',models}` only after Comfy acknowledges one queue submission. A network error after submission produces `SUBMISSION_UNKNOWN`, never an automatic retry.

`buildPrompt({objectInfo,references:[{imageName,frameIndex?}],prompt,params,jobKey})` constructs the exact named/flat API graph without submitting it.

Readiness queries only `/object_info` and `/system_stats`; polling queries only `/history/<promptId>` and `/queue`. Uploads are sent only to an allowed loopback HTTP Comfy host. Redirects are rejected. The backend must keep its own Origin/Host checks and private upload IDs.

## Verification performed

27 source-fixture unit tests passed: 15 legacy-adapter tests and 12 multi-reference tests. These cover DynamicCombo paths and legacy fallback, Autogrow reference order/cardinality, no default first/end frames, explicit interior Guide chaining, model selection, schema mismatch, mock submission/no automatic retry, and prompt-bound output lookup. Every upload and queue operation in these tests used an injected mock fetch; no live `/prompt` call or GPU sampling was made.

Actual local hardware, absence of a running Comfy listener, and license research are recorded in `H3-RESEARCH.md`. That historical report is not proof that this new graph has run on the colleague's 4090. A real video result remains unverified.
