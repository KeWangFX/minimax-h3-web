# H3 Multi-frame Reference Web

多张角色、场景、道具图片 + 提示词 → 同事电脑上的 ComfyUI → 真实视频预览与下载。

## 同事只需做这几步

1. 解压部署包，先启动同一电脑上的 ComfyUI。默认地址为 `http://127.0.0.1:8188`，不要开放 8188 到公网。
2. 安装 Node.js 22+（已有则不需要）；双击 `Start-H3Web.cmd`。无需 npm install。
3. 打开 `http://127.0.0.1:9860/`。核对运行环境缺项；按社区许可条件自行确认后，将 `config.env` 中 `H3_LICENSE_CONFIRMED` 改为 `1` 并重启连接器。
4. 若从公开网页操作，输入本机网页上的 6 位连接码配对。浏览器若询问访问本地网络，需由使用者自行允许。配对有效 8 小时，重启连接器立即失效。
5. 上传 1–9 张参考图，按 `<Picture 1>`、`<Picture 2>` 编号写提示词，然后生成。

## 不固定首尾帧

以官方 `video_minimax_h3_multiframe_reference` 模板的 Ref2VA + AddGuide 图为依据。每张图默认进入语义参考，不会自动成为视频起始画面。需要精确中段构图时可指定中间帧，拒绝帧 0 和末帧。没有指定中间帧时，不插入 AddGuide 约束。

## 质量优先

- 默认 1344×768、原生 24fps、124 帧（约 5.17 秒）、50 步、固定种子 42、参考图 `max`。官方模板参考步数较低；增加步数不是已验证的质量保证。
- 不启用 Turbo / Lightning LoRA，不自动下调分辨率；BF16 权重优先，也可明确指定 BF16 或 INT8。实际文件名会显示，缺少指定精度时不会伪装使用成功。
- 1920×1088 为实验大画幅。官方 H3-Regenerate-2K 托管模块不在本工具中调用，不宣称已复现其质量。
- 使用节点支持的 MP4 H.264 / CRF16；旧节点无法设定 CRF 时明确显示使用节点默认编码。没有锐化、假补帧或假 HDR。
- 网页不自动把两张显卡显存相加；实际多卡调度由 ComfyUI / 推理后端配置决定。

## 模型

本工具不包含权重、不自动接受模型许可。质量档用 Ref2VA，不是 FL2VA。D 盘模型包按 ComfyUI 的 `models/diffusion_models`、`models/text_encoders`、`models/vae` 分类。可复制到同事的 ComfyUI 模型目录，或由同事配置其已有额外模型路径。

官方来源：

- https://github.com/Comfy-Org/workflow_templates/blob/main/templates/video_minimax_h3_multiframe_reference.json
- https://huggingface.co/Comfy-Org/MiniMax-H3
- https://huggingface.co/MiniMaxAI/MiniMax-H3/blob/main/LICENSE
- https://comfy.org/minimax/license

## 安全与费用边界

网页静态托管不提供 GPU。媒体、提示词、配对码不上传到静态网站服务器；公开页面只与配对的同机连接器通信。连接器只监听 `127.0.0.1`，只连接本机 ComfyUI。准确 HTTPS origin + 单次连接码 + 操作令牌 + CSRF；视频另用只读媒体令牌支持 Range 播放。没有 API key、收费接口或自动云服务开通。

先评估了阿里云方案：FC 试用有资格与时限、超量转按量计费，不能据此保证长期零费用 GPU。当前采用同事已有电脑 + 免费静态网页，不创建云资源。中国大陆访问静态域名的实际线路表现仍需同事测试。

本地生成无本工具收取的按次费用，但电费、网络及模型协议条件仍由部署者自行确认；不能承诺所有商业用途无条件免费。

## 验证边界

单元与 HTTP 模拟测试用于验证多图顺序、参数、任务、配对、安全、Range 输出。它们不是一次真实 H3 视频生成。只有同事的实际模型、节点、机器完成采样后，才能报告推理跑通。

启动：`node server.mjs`；测试：`node --test tests/*.test.mjs`。
