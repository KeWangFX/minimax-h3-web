import http from 'node:http';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createStore, ID_PATTERN } from './lib/store.mjs';
import { inspectImage } from './lib/server-images.mjs';
import { createPairing } from './lib/pairing.mjs';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const MAX_UPLOAD = 32 * 1024 * 1024;
const MAX_JSON = 64 * 1024;
const ACTIVE = new Set(['queued', 'running']);
const STATIC = new Map([['/', ['index.html', 'text/html; charset=utf-8']], ['/app.js', ['app.js', 'text/javascript; charset=utf-8']], ['/app.css', ['app.css', 'text/css; charset=utf-8']]]);

class HttpError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

export function validateComfyUrl(value) {
  let url;
  try { url = new URL(value); } catch { throw new Error('COMFY_URL 必须是本机 HTTP 地址'); }
  if (url.protocol !== 'http:' || !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw new Error('仅允许本机 ComfyUI，例如 http://127.0.0.1:8188');
  return url.origin;
}

function json(res, status, body) {
  const bytes = Buffer.from(JSON.stringify(body));
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': bytes.length });
  res.end(bytes);
}

async function readBody(req, max) {
  const length = Number(req.headers['content-length']);
  if (Number.isFinite(length) && length > max) {
    req.resume();
    throw new HttpError(413, 'BODY_TOO_LARGE', `上传内容超过 ${Math.round(max / 1024 / 1024)} MiB 限制`);
  }
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > max) throw new HttpError(413, 'BODY_TOO_LARGE', '上传内容过大');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks, total);
}

function publicJob(job) {
  const uploadIds = Array.isArray(job.uploadIds) ? job.uploadIds : job.uploadId ? [job.uploadId] : [];
  return {
    id: job.id, status: job.status, createdAt: job.createdAt, updatedAt: job.updatedAt,
    workflow: job.workflow ?? 'legacy_i2v',
    prompt: job.prompt, params: job.params, message: job.message,
    progress: Number.isFinite(job.progress) ? Math.max(0, Math.min(100, job.progress)) : null,
    uploadUrls: uploadIds.map(id => `/api/uploads/${id}`),
    uploadUrl: uploadIds[0] ? `/api/uploads/${uploadIds[0]}` : undefined,
    references: Array.isArray(job.references) ? job.references : [],
    ...(safeModels(job.models) ? { models: safeModels(job.models) } : {}),
    seed: job.seed ?? job.params?.seed,
    ...(job.status === 'succeeded' && job.output ? { videoUrl: `/api/jobs/${job.id}/video`, downloadUrl: `/api/jobs/${job.id}/video?download=1` } : {}),
  };
}

function safeModels(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return undefined;
  const entries = ['unet', 'clip', 'video', 'audio'].filter(key => typeof value[key] === 'string' && value[key].length <= 1024).map(key => [key, value[key].replace(/[\x00-\x1f\x7f]/g, '')]);
  return entries.length ? Object.fromEntries(entries) : undefined;
}

function outputTuple(value) {
  if (!value || typeof value.filename !== 'string' || value.filename.length > 255 || /[\\/\x00-\x1f]/.test(value.filename) || value.filename === '.' || value.filename === '..' || !/\.(mp4|webm|mov)$/i.test(value.filename)) throw new Error('ComfyUI 未返回可播放的视频文件');
  const subfolder = value.subfolder ?? '';
  if (typeof subfolder !== 'string' || subfolder.length > 1024 || /[\\:\x00-\x1f]/.test(subfolder) || subfolder.startsWith('/') || subfolder.split('/').some(p => p === '.' || p === '..')) throw new Error('视频路径不符合本机输出规则');
  if (value.type !== 'output') throw new Error('视频必须来自 ComfyUI output 目录');
  return { filename: value.filename, subfolder, type: 'output' };
}

export async function createApp({ adapter, config = {}, fetchImpl = globalThis.fetch } = {}) {
  adapter ??= await import('./lib/multiframe-adapter.mjs');
  const comfyUrl = validateComfyUrl(config.comfyUrl ?? process.env.COMFY_URL ?? 'http://127.0.0.1:8188');
  const port = Number(config.port ?? process.env.PORT ?? 9860);
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('无效的监听端口');
  const dataRoot = path.resolve(config.dataRoot ?? path.join(ROOT, 'data'));
  const staticRoot = path.resolve(config.staticRoot ?? path.join(ROOT, 'public'));
  const store = await createStore(dataRoot);
  const csrfToken = randomBytes(32).toString('hex');
  const pairing = createPairing({ publicOrigin: config.publicOrigin ?? process.env.H3_PUBLIC_ORIGIN ?? '' });
  const timers = new Map();
  const inFlight = new Set();
  const pollIntervalMs = config.pollIntervalMs ?? 2000;
  let closed = false;
  let activeId = null;

  const adapterArgs = { baseUrl: comfyUrl, fetchImpl };
  function track(work) {
    const task = Promise.resolve(work);
    inFlight.add(task);
    task.then(() => inFlight.delete(task), error => {
      inFlight.delete(task);
      // Keep filesystem failures observable without printing prompts or private paths.
      console.error('H3 background task failed:', error?.code ?? 'LOCAL_ERROR');
    });
    return task;
  }
  function schedule(id) {
    if (closed) return;
    const timer = setTimeout(() => { timers.delete(id); track(poll(id)); }, pollIntervalMs);
    timer.unref();
    timers.set(id, timer);
  }

  async function update(job, fields) {
    return store.saveJob({ ...job, ...fields, updatedAt: new Date().toISOString() });
  }

  async function poll(id) {
    const job = store.jobs.get(id);
    if (closed || !job || !ACTIVE.has(job.status) || !job.promptId) return;
    try {
      const result = await adapter.pollJob({ ...adapterArgs, promptId: job.promptId, outputNodeId: job.outputNodeId });
      const status = ['queued', 'running', 'succeeded', 'failed', 'blocked'].includes(result.status) ? result.status : 'running';
      let output;
      if (status === 'succeeded') {
        try { output = outputTuple(result.output); }
        catch {
          // An invalid completed output is not a transient connection failure.
          await update(job, { status: 'failed', message: 'ComfyUI 已结束，但未返回受支持的 output 视频文件；请检查工作流保存节点', progress: null });
          if (activeId === id) activeId = null;
          return;
        }
      }
      await update(job, { status, message: result.message ?? (status === 'succeeded' ? '视频生成完成' : '等待 ComfyUI 返回结果'), progress: result.progress ?? null, ...(output ? { output } : {}), pollFailures: 0 });
      if (ACTIVE.has(status)) schedule(id); else if (activeId === id) activeId = null;
    } catch {
      // Polling is read-only and can be retried. Submission is never retried.
      await update(job, { message: '暂时无法读取 ComfyUI 任务状态，正在重新连接；不会重复提交', pollFailures: (job.pollFailures ?? 0) + 1 });
      schedule(id);
    }
  }

  async function submit(job, uploads) {
    try {
      if (closed) return;
      await update(job, { phase: 'submitting', message: '正在提交本地 ComfyUI 工作流' });
      if (closed) {
        await update(store.jobs.get(job.id), { status: 'blocked', phase: 'stopped_before_submit', message: '应用在提交前关闭，未向 ComfyUI 入队', progress: null });
        if (activeId === job.id) activeId = null;
        return;
      }
      if (typeof adapter.submitMultiReference !== 'function') throw Object.assign(new Error('当前适配器不支持 multiframe_reference，请更新工作流；不会退回首帧 I2V'), { code: 'SCHEMA_MISMATCH' });
      const result = await adapter.submitMultiReference({
        ...adapterArgs,
        uploads: uploads.map((upload, index) => ({
          path: path.join(store.uploadsRoot, `${upload.id}.${upload.extension}`), name: upload.name, mime: upload.mime,
          frameIndex: job.references[index]?.frameIndex ?? null,
          label: job.references[index]?.label ?? '', note: job.references[index]?.note ?? '',
        })),
        references: job.references,
        prompt: job.prompt,
        params: job.params,
      });
      if (!result || typeof result.promptId !== 'string' || result.promptId.length > 200) throw new Error('Invalid prompt result');
      const current = store.jobs.get(job.id);
      await update(current, { promptId: result.promptId, seed: result.seed, outputNodeId: result.outputNodeId, models: safeModels(result.models), phase: 'submitted', status: 'queued', message: '已提交，等待本机 ComfyUI 生成', progress: null });
      schedule(job.id);
    } catch (error) {
      const current = store.jobs.get(job.id);
      const knownPreflightFailure = new Set(['NOT_READY', 'SCHEMA_MISMATCH', 'MODEL_MISSING', 'NODE_MISSING', 'INVALID_INPUT', 'UPLOAD_FAILED', 'COMFY_HTTP_ERROR']).has(error?.code);
      // Only explicit pre-submit adapter codes are safe to describe as not enqueued.
      const detail = String(error?.message ?? '本机预检失败').replace(/[\x00-\x1f\x7f]/g, ' ').slice(0, 1200);
      await update(current, {
        status: knownPreflightFailure ? 'blocked' : 'failed',
        phase: knownPreflightFailure ? 'preflight_failed' : 'submission_unknown',
        progress: null,
        message: knownPreflightFailure ? `未提交生成：${detail}` : '本地任务提交未确认。为避免重复运行，未自动重试；请先检查 ComfyUI 队列。',
        errorCode: error?.code ?? 'SUBMISSION_UNCONFIRMED',
      });
      if (activeId === job.id) activeId = null;
    }
  }

  // A restart resumes read-only polling only. It must never replay a POST /prompt.
  for (const job of [...store.jobs.values()].sort((a, b) => a.createdAt.localeCompare(b.createdAt))) {
    if (!ACTIVE.has(job.status)) continue;
    if (job.promptId && !activeId) {
      activeId = job.id;
      schedule(job.id);
    } else {
      await update(job, { status: 'failed', phase: 'interrupted', message: '应用曾中断，提交状态未确认。未重新入队；请核对 ComfyUI 后手动新建任务。', progress: null });
    }
  }

  const server = http.createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    try {
      const listeningPort = server.address()?.port ?? port;
      const pairingResult = await pairing.handle(req, res, { listeningPort });
      if (pairingResult.handled) return;
      const crossOrigin = pairingResult.crossOrigin === true;
      const allowedHosts = [`127.0.0.1:${listeningPort}`, `localhost:${listeningPort}`];
      if (!allowedHosts.includes(req.headers.host)) throw new HttpError(403, 'LOCALHOST_ONLY', '此工具只允许本机访问');
      const origin = req.headers.origin;
      if (!crossOrigin && ((origin && !allowedHosts.some(host => origin === `http://${host}`)) || req.headers['sec-fetch-site'] === 'cross-site')) throw new HttpError(403, 'ORIGIN_DENIED', '不接受其他网站发起的请求');
      if (!['GET', 'HEAD', 'POST'].includes(req.method)) throw new HttpError(405, 'METHOD_NOT_ALLOWED', '不支持的请求方法');
      if (req.method === 'POST') {
        const supplied = Buffer.from(typeof req.headers['x-csrf-token'] === 'string' ? req.headers['x-csrf-token'] : '');
        const expected = Buffer.from(csrfToken);
        if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) throw new HttpError(403, 'CSRF_REJECTED', '页面校验已失效，请刷新后重试');
      }
      const url = new URL(req.url, 'http://127.0.0.1');
      const pathname = url.pathname;

      if (req.method === 'GET' && pathname === '/api/status') {
        let inspection;
        try { inspection = await adapter.inspectComfy(adapterArgs); }
        catch { inspection = { ready: false, comfy: { connected: false }, checks: [{ id: 'connection', label: '本机 ComfyUI', ok: false, detail: '无法连接，请先启动本地 ComfyUI' }] }; }
        const checks = (Array.isArray(inspection.checks) ? inspection.checks : []).map(check => ({ id: String(check.id ?? ''), label: String(check.label ?? ''), ok: check.ok === true, detail: String(check.detail ?? '') }));
        const localPairing = pairing.localInfo();
        const pairingInfo = crossOrigin ? { enabled: localPairing.enabled, publicOrigin: localPairing.publicOrigin, paired: true } : localPairing;
        json(res, 200, { ok: true, ready: inspection.ready === true, workflow: 'multiframe_reference', comfy: { url: comfyUrl, connected: inspection.comfy?.connected === true, ...(inspection.comfy?.gpu ? { gpu: inspection.comfy.gpu } : {}), ...(inspection.comfy?.vramMB ? { vramMB: inspection.comfy.vramMB } : {}) }, checks, defaults: adapter.DEFAULTS, limits: { ...adapter.LIMITS, uploadBytes: MAX_UPLOAD, maxReferenceImages: 9 }, ...(safeModels(inspection.models) ? { models: safeModels(inspection.models) } : {}), csrfToken, pairing: pairingInfo, message: inspection.message ?? (inspection.ready ? '本地多参考图工作流已就绪' : '请先完成本地环境检查'), warnings: store.warnings });
        return;
      }
      if (req.method === 'GET' && pathname === '/api/jobs') {
        json(res, 200, { jobs: [...store.jobs.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).map(publicJob) });
        return;
      }
      if (req.method === 'POST' && pathname === '/api/uploads') {
        const mime = String(req.headers['content-type'] ?? '').split(';')[0].toLowerCase();
        if (!['image/png', 'image/jpeg', 'image/webp'].includes(mime)) throw new HttpError(415, 'IMAGE_TYPE', '仅支持 PNG、JPEG、静态 WebP');
        const bytes = await readBody(req, MAX_UPLOAD);
        let dimensions;
        try { dimensions = inspectImage(bytes, mime); } catch (error) { throw new HttpError(400, 'INVALID_IMAGE', error.message); }
        let name = 'image';
        try { name = decodeURIComponent(String(req.headers['x-filename'] ?? 'image')); } catch { throw new HttpError(400, 'INVALID_NAME', '文件名称编码无效'); }
        name = name.replace(/[\x00-\x1f\x7f]/g, '').slice(0, 200);
        const upload = { id: randomUUID(), name: name || 'image', mime, bytes: bytes.length, ...dimensions, createdAt: new Date().toISOString() };
        await writeFile(path.join(store.uploadsRoot, `${upload.id}.${upload.extension}`), bytes, { flag: 'wx', mode: 0o600 });
        await store.saveUpload(upload);
        json(res, 201, { id: upload.id, name: upload.name, mime, bytes: upload.bytes, width: upload.width, height: upload.height, url: `/api/uploads/${upload.id}` });
        return;
      }
      if (req.method === 'POST' && pathname === '/api/jobs') {
        if (activeId) throw new HttpError(409, 'ACTIVE_JOB', '已有本机任务在执行，请等待完成');
        if (!String(req.headers['content-type'] ?? '').startsWith('application/json')) throw new HttpError(415, 'JSON_REQUIRED', '请使用 JSON 请求');
        let body;
        try { body = JSON.parse((await readBody(req, MAX_JSON)).toString('utf8')); } catch (error) { if (error instanceof HttpError) throw error; throw new HttpError(400, 'INVALID_JSON', '无效的 JSON 请求'); }
        if (!body || typeof body !== 'object' || Array.isArray(body)) throw new HttpError(400, 'INVALID_BODY', '无效的任务请求');
        // Single-ID legacy clients still enter the multi-reference workflow, never I2V.
        const uploadIds = body.uploadIds ?? (body.uploadId ? [body.uploadId] : null);
        if (!Array.isArray(uploadIds) || uploadIds.length < 1 || uploadIds.length > 9 || uploadIds.some(id => typeof id !== 'string' || !ID_PATTERN.test(id)) || new Set(uploadIds).size !== uploadIds.length) throw new HttpError(400, 'INVALID_REFERENCES', '请上传 1–9 张不重复的参考图片');
        if (body.uploadIds !== undefined && body.uploadId !== undefined) throw new HttpError(400, 'AMBIGUOUS_REFERENCES', '请只使用 uploadIds 参考图列表');
        const uploads = uploadIds.map(id => store.uploads.get(id));
        if (uploads.some(upload => !upload)) throw new HttpError(400, 'UPLOAD_REQUIRED', '参考图片不存在，请重新上传');
        if (body.workflow !== undefined && body.workflow !== 'multiframe_reference') throw new HttpError(400, 'WORKFLOW_MISMATCH', '此页面只支持 multiframe_reference，不使用首帧 I2V');
        let params;
        try { params = adapter.validateParams(body.params ?? {}); } catch (error) { throw new HttpError(400, 'INVALID_PARAMS', error.message); }
        if (body.references !== undefined && (!Array.isArray(body.references) || body.references.length > 9)) throw new HttpError(400, 'INVALID_REFERENCES', '参考图说明格式无效');
        const referenceMap = new Map();
        const referenceFrames = new Set();
        for (const reference of body.references ?? []) {
          if (!reference || typeof reference !== 'object' || Array.isArray(reference) || !uploadIds.includes(reference.uploadId) || referenceMap.has(reference.uploadId) || (reference.label !== undefined && (typeof reference.label !== 'string' || reference.label.length > 100)) || (reference.note !== undefined && (typeof reference.note !== 'string' || reference.note.length > 1000))) throw new HttpError(400, 'INVALID_REFERENCES', '每张参考图的名称最多 100 字、说明最多 1000 字，且必须对应当前图片');
          const frameIndex = reference.frameIndex ?? null;
          if (frameIndex !== null && (!Number.isInteger(frameIndex) || frameIndex < 1 || frameIndex > params.frames - 2)) throw new HttpError(400, 'INVALID_REFERENCE_FRAME', `参考帧只能留空或设为 1–${params.frames - 2} 的中间帧，不使用首帧或末帧`);
          if (frameIndex !== null && referenceFrames.has(frameIndex)) throw new HttpError(400, 'DUPLICATE_REFERENCE_FRAME', '同一中间帧不能绑定两张冲突的参考图片');
          if (frameIndex !== null) referenceFrames.add(frameIndex);
          referenceMap.set(reference.uploadId, { label: (reference.label ?? '').replace(/[\x00-\x1f\x7f]/g, ' ').trim(), note: (reference.note ?? '').replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, '').trim(), frameIndex });
        }
        const references = uploadIds.map(uploadId => ({ uploadId, ...(referenceMap.get(uploadId) ?? { label: '', note: '', frameIndex: null }) }));
        const maxPromptLength = Number.isSafeInteger(adapter.LIMITS?.maxPromptLength) && adapter.LIMITS.maxPromptLength > 0 ? adapter.LIMITS.maxPromptLength : 8000;
        if (typeof body.prompt !== 'string' || !body.prompt.trim() || body.prompt.length > maxPromptLength) throw new HttpError(400, 'PROMPT_REQUIRED', `请填写 1–${maxPromptLength} 字的视频提示词`);
        const inspection = await adapter.inspectComfy({ ...adapterArgs, params });
        if (inspection.ready !== true) throw new HttpError(409, 'NOT_READY', inspection.message ?? '本地节点或模型尚未就绪，请先完成环境检查');
        // Recheck after the asynchronous readiness probe to prevent concurrent double submission.
        if (activeId) throw new HttpError(409, 'ACTIVE_JOB', '已有本机任务在执行，请等待完成');
        const now = new Date().toISOString();
        const job = { id: randomUUID(), workflow: 'multiframe_reference', uploadIds, uploadId: uploadIds[0], references, prompt: body.prompt.trim(), params, createdAt: now, updatedAt: now, status: 'queued', phase: 'created', message: '已创建本地多参考图任务', progress: null };
        activeId = job.id;
        try { await store.saveJob(job); } catch (error) { activeId = null; throw error; }
        json(res, 202, { job: publicJob(job) });
        track(submit(job, uploads));
        return;
      }

      const uploadMatch = pathname.match(/^\/api\/uploads\/([^/]+)$/);
      if (['GET', 'HEAD'].includes(req.method) && uploadMatch) {
        const upload = ID_PATTERN.test(uploadMatch[1]) ? store.uploads.get(uploadMatch[1]) : null;
        if (!upload || !['png', 'jpg', 'webp'].includes(upload.extension)) throw new HttpError(404, 'NOT_FOUND', '图片不存在');
        const filename = path.join(store.uploadsRoot, `${upload.id}.${upload.extension}`);
        const info = await stat(filename);
        res.writeHead(200, { 'Content-Type': upload.mime, 'Content-Length': info.size });
        if (req.method === 'HEAD') res.end(); else await pipeline(createReadStream(filename), res);
        return;
      }
      const jobMatch = pathname.match(/^\/api\/jobs\/([^/]+)(\/video)?$/);
      if (['GET', 'HEAD'].includes(req.method) && jobMatch) {
        const job = ID_PATTERN.test(jobMatch[1]) ? store.jobs.get(jobMatch[1]) : null;
        if (!job) throw new HttpError(404, 'NOT_FOUND', '任务不存在');
        if (!jobMatch[2]) { json(res, 200, { job: publicJob(job) }); return; }
        if (job.status !== 'succeeded' || !job.output) throw new HttpError(409, 'VIDEO_NOT_READY', '此任务尚未生成可用视频');
        const output = outputTuple(job.output);
        const viewUrl = new URL(`${comfyUrl}/view`);
        Object.entries(output).forEach(([key, value]) => viewUrl.searchParams.set(key, value));
        const range = req.headers.range;
        if (range && !/^bytes=(?:\d+-\d*|-\d+)$/.test(range)) throw new HttpError(416, 'INVALID_RANGE', '不支持此视频范围请求');
        const upstream = await fetchImpl(viewUrl, { method: req.method, headers: range ? { Range: range } : {}, redirect: 'error', signal: AbortSignal.timeout(30000) });
        if (![200, 206, 416].includes(upstream.status)) throw new HttpError(502, 'COMFY_VIDEO_ERROR', '无法读取 ComfyUI 输出视频，请确认其仍在本机 output 目录');
        const lowerFilename = output.filename.toLowerCase();
        const headers = { 'Content-Type': lowerFilename.endsWith('.webm') ? 'video/webm' : lowerFilename.endsWith('.mov') ? 'video/quicktime' : 'video/mp4', 'Accept-Ranges': 'bytes' };
        for (const key of ['content-length', 'content-range']) { if (upstream.headers.has(key)) headers[key] = upstream.headers.get(key); }
        if (url.searchParams.get('download') === '1') headers['Content-Disposition'] = `attachment; filename="h3-${job.id}.${output.filename.split('.').pop().toLowerCase()}"`;
        res.writeHead(upstream.status, headers);
        if (req.method === 'HEAD' || !upstream.body) res.end(); else await pipeline(Readable.fromWeb(upstream.body), res);
        return;
      }
      if (['GET', 'HEAD'].includes(req.method) && STATIC.has(pathname)) {
        const [filename, mime] = STATIC.get(pathname);
        const bytes = await readFile(path.join(staticRoot, filename));
        res.writeHead(200, { 'Content-Type': mime, 'Content-Length': bytes.length });
        res.end(req.method === 'HEAD' ? undefined : bytes);
        return;
      }
      throw new HttpError(404, 'NOT_FOUND', '页面或接口不存在');
    } catch (error) {
      if (res.headersSent) { res.destroy(); return; }
      json(res, error instanceof HttpError ? error.status : 500, { ok: false, error: { code: error instanceof HttpError ? error.code : 'LOCAL_ERROR', message: error instanceof HttpError ? error.message : '本机处理失败，请检查应用日志后重试' } });
    }
  });
  server.requestTimeout = 60000;
  server.headersTimeout = 15000;
  const close = async () => {
    closed = true;
    for (const timer of timers.values()) clearTimeout(timer);
    timers.clear();
    await new Promise((resolve, reject) => { if (!server.listening) return resolve(); server.close(error => error ? reject(error) : resolve()); server.closeIdleConnections(); });
    // Background disk writes outlive HTTP responses. Drain them before reporting closed.
    while (inFlight.size) await Promise.allSettled([...inFlight]);
  };
  return { server, close, store, config: { port, comfyUrl, dataRoot }, listen: () => new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, '127.0.0.1', () => resolve(server.address())); }) };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const app = await createApp();
  const address = await app.listen();
  console.log(`MiniMax H3 本地网页：http://127.0.0.1:${address.port}`);
  console.log(`仅连接本机 ComfyUI：${app.config.comfyUrl}`);
  for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => { void app.close().then(() => process.exit(0)); });
}
