@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or newer is required. Install Node.js LTS from https://nodejs.org/
  pause
  exit /b 1
)
if not exist config.env copy /y config.env.example config.env >nul
echo H3 Multi-frame Reference Local Connector
echo Open http://127.0.0.1:9860/ to see your pairing code.
echo Keep this window open. ComfyUI stays on localhost only.
node --env-file-if-exists=config.env server.mjs
pause
